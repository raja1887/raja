 <?php


$img=basename($_FILES["image"]["name"]);
$old=$_GET["img"];
if($img=="")
{
    $img=$old;
}
else
{

  $target_dir="../shared/images/userimg/";
  $uimg=$target_dir . basename($_FILES["image"]["name"]); 
    echo $uimg;


if(move_uploaded_file($_FILES["image"]["tmp_name"],$uimg))
{
  echo "success";
  $img=$uimg;
}
}


$email=$_POST["txtemail"];
$name=$_POST["txtname"];

$gender=$_POST["txtgender"];
$mobile=$_POST["txtmobile"];

$address=$_POST["txtaddress"];
    
    $conn=new mysqli("localhost","root","","project");
    

    $sql="update user_tbl set uname='". $name ."',mobile_no='". $mobile ."',gender='". $gender ."',address='". $address ."',profile_pic='". $img ."'where pk_email_id='". $email ."'";

if($conn->query($sql)===true){
   header('location:viewprofile.php');
}
else
{
    echo "not success";
     echo $sql;
}


?>