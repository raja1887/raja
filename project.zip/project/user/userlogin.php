 <?php
 session_start();
 ?>
 
 <!DOCTYPE HTML>
<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Login :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
</head>
<body>	

 <?php
if(isset($_POST["btnlogin"]))
{
 $email=$_POST["email"];
$password=$_POST["password"];
$f=0;
 require 'databaseuser.php';
$obj= new database();
$result=$obj->getLoginUser($email,$password);


if($result->num_rows==1){
 $row=$result->fetch_assoc();
 $_SESSION["uname"]=$email;

if($row["user_type"]=="admin")
{

  header('location:../admin/protable.php');
}
else{


  header('location:loginproducts.php');}
if($row["flag"]==1)
{
  echo "Successful";
  
  $_SESSION["password"]=$password;
 
}
else
{
echo "not varified <a href=emaildemo.php>resend</a>";
}
}





else
{
echo '<script language="javascript">';
echo 'alert("Enter Valid Details")';

echo '</script>';
if($f=0)
{
header('location:login.php');
}





}
}
?>
</body>
</html>