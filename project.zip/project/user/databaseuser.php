<?php
class database{
private static $con=null;
private static function connect(){
    self::$con=mysqli_connect('localhost','root','','project');
    return self::$con;
}

private static function disconnect(){
    mysqli_close(self::$con);
    self::$con=null;
}

public function getSignup($email,$name,$password,$address,$mobile,$gender,$img,$flag,$token,$user_type){
    $conn=database::connect();
    $sql="insert into user_tbl (pk_email_id,uname,password,address,mobile_no,gender,profile_pic,user_type,flag,token) values('". $email ."','". $name ."','". $password ."','". $address ."','". $mobile ."','". $gender ."','". $img ."','".$user_type."','".$flag."','".$token."')";
    $res=$conn->query($sql);
    database::disconnect();
    return $res;
}


public function getLoginUser($email,$password){
    $conn=database::connect();
    $sql="select * from user_tbl where pk_email_id='". $email ."' and password='". $password ."' ";
    $res=$conn->query($sql);
    database::disconnect();
    return $res;
}

public function getProfileUser($email){
    $conn=database::connect();
    $sql="select * from user_tbl where pk_email_id='". $email ."'";
    $res=$conn->query($sql);
    database::disconnect();
    return $res;
}

public function forgotUser($email){
    $conn=database::connect();
    $sql="select password from user_tbl where pk_email_id='". $email ."'";
    $res=$conn->query($sql);    
   
    database::disconnect();
    return $res;

}

public function getCp($email,$password,$newpassword){
    $conn=database::connect();
    $sql="select * from user_tbl where pk_email_id='". $email ."' and password='". $password ."' ";
    $res=$conn->query($sql);
    if($res->num_rows==1)
    {
        $sql="update user_tbl set password='". $newpassword ."' where pk_email_id='".$email."'";
         $res=$conn->query($sql);
         return $res;
    }
    else
    {
        echo "failed";
    }
    database::disconnect();

    return $res;

    }


}

?>