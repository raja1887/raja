<?php
$cart_id=$_GET["id"];
$conn=mysqli_connect('localhost','root','','project');
$sql="delete from cart_tbl where pk_cart_id='".$cart_id."'";

$result=$conn->query($sql);
if($conn->query($sql)===true){
       header('location:cart.php');
 }
?>