<?php
session_start();
$id=$_GET["id"];
echo $id;
$qty=3;
$email=$_SESSION["uname"];

$conn=mysqli_connect('localhost','root','','project');
$sql="insert into cart_tbl (fk_email_id,fk_pro_id,cart_qty) values('". $email ."','". $id ."','". $qty ."')";
if($conn->query($sql)===true){
    echo "successfully";
    header('location:cart.php');
    
}
?>