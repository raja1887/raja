<?php

if(isset($_POST["btnsignup"]))
{
 $email=$_POST["email"];
 $name=$_POST["name"];
 $password=$_POST["password"];
 $mobile=$_POST["mobile"];
 $address=$_POST["address"];
 $gender=$_POST["rbt"];
 $flag="1";
 $token="";
 $user_type="user";    
 
 
 
  $target_dir="../shared/images/userimg/";
  $img=$target_dir . basename($_FILES["img"]["name"]);
 
 
 move_uploaded_file($_FILES["img"]["tmp_name"],$img);
 


require 'databaseuser.php';
$obj= new database();
$result=$obj->getSignup($email,$name,$password,$address,$mobile,$gender,$img,$flag,$token,$user_type);



if($result===true){
    echo "successful";
    header('location:login.php');

}
else
{
    echo "not success";
echo "insert into user_tbl (pk_email_id,uname,password,address,mobile_no,gender,profile_pic,user_type,flag,token) values('". $email ."','". $name ."','". $password ."','". $address ."','". $mobile ."','". $gender ."','". $img ."','".$user_type."','".$flag."','".$token."')";
}



}



?>