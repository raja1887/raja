<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();

?>

<!DOCTYPE HTML>


<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Blank :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="loginproducts.php"> <h1>Shoppy</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box-->
								
								
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
											<?php
    $conn=new mysqli("localhost","root","","project");
    if($conn->connect_error)
    {
        echo "connection error";
    }
$email=$_SESSION["uname"];
$sql="select * from user_tbl where pk_email_id='".$email."' ";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
$img=$row["profile_pic"];
$name=$row["uname"];
$type=$row["user_type"];

	
												echo '<span class="prfil-img"><img src="'.$img.'" alt="" height="50" width="50"> </span>'; 
												echo '<div class="user-name">';
												echo  '<p>'.$name.'</p>';
												echo  '<span>'.$type.'</span>';
													?>	
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu"> 
											<li> <a href="viewprofile.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="login.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
									</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
     <?php
   

   $email=$_SESSION["uname"];
   
   require 'databaseuser.php';
$obj= new database();
$result=$obj->getProfileUser($email);

?>

<form action="userupdate.php" method="post">
<div class="container">
<table class="table" align="center">
<thead>
<tr>
<td> <h1>Profile</h1>
</thead>
<?php
$row=$result->fetch_assoc();

echo '<tr>';
echo '<th>Profile Pic :';
echo '<td><div class="row">';
  echo'<div class="col-sm-6 col-md-4">';
    echo'<div class="thumbnail">';
      echo'<img src="'.$row["profile_pic"].'" alt="left">';
   

   echo '</div>';
  echo '</div>';
echo '</div>';

echo '<tr>';
echo '<th> User Name :';
echo '<td> <h2>'.$row["uname"].'</h2>';

echo '<tr>';
echo '<th> Email Address';
echo '<td>'.$row["pk_email_id"];

echo '<tr>';
echo '<th> Mobile NO :';
echo '<td>'.$row["mobile_no"];

echo '<tr>';
echo '<th> Address :';
echo '<td>'.$row["address"];


echo '<tr>';
echo '<th> Gender :';
echo '<td>'.$row["gender"];



?>
<tr>
<td colspan="2">
<a href="editprofile.php" class="btn btn-info">Edit</a>
<a href="login.php" class="btn btn-danger">Log out</a>
</table>
</div>
</form>
</div>

<!--inner block end here-->


</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="loginproducts.php"><i class="fa fa-home"></i><span>Home</span></a></li>
                <li><a href="viewprofile.php"><i class="fa fa-user"></i><span>View Profile</span></a></li> 
                <li><a href="editprofile.php"><i class="fa fa-list"></i><span>Edit Profile</span></a></li>
                 <li><a href="changepass.php"><i class="fa fa-list-alt"></i><span>Change Password</span></a></li>
		           <li><a href="cart.php"><i class="fa fa-shopping-cart"></i><span>Cart</span></a></li>
		       
		       
		        
		       
		        
		        
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>


                      
						
