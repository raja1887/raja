<?php
session_start();
$email=$_SESSION["uname"];
$password=$_POST["txtpass"];
$newpassword=$_POST["txtnewpass"];

$conpassword=$_POST["txtconpass"];




if($newpassword==$conpassword)
{
    require 'databaseuser.php';
    $obj=new database;
    $result=$obj->getCp($email,$password,$newpassword);
    if($result===true){
    header('location:login.php');
}
}
else
{
    echo "Not Successful";
}


?>
