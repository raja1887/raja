
 <?php
$pk_pro_id=$_POST["proid"];
$pro_name=$_POST["proname"];
$pro_price=$_POST["proprice"];
$pro_mfg=$_POST["promfg"];
$pro_color=$_POST["procolor"];
$pro_warrenty=$_POST["prowarrenty"];
$pro_soh=$_POST["prosoh"];
$pro_desc=$_POST["prodesc"];

$pro_img=basename($_FILES["img"]["name"]);
$old=$_GET["img"];
if($pro_img=="")
{
    $pro_img=$old;
}
else
{

  $target_dir="images/";
  $img=$target_dir . basename($_FILES["img"]["name"]); 
    echo $img;


if(move_uploaded_file($_FILES["img"]["tmp_name"],$img))
{
  echo "success";
  $pro_img=$img;
}
}

    


    
  require 'databaseproduct.php';
   $obj=new database();
   $result=$obj->updateProducts($pro_name,$pro_price,$pro_mfg,$pro_color,$pro_warrenty,$pro_soh,$pro_desc,$pro_img,$pk_pro_id);
    

    

if($result===true){
  
   header('location:protable.php');
}
else
{
    echo "not success";
echo "update product_tbl set pro_name='". $pro_name ."',pro_price='". $pro_price ."',pro_mfg='". $pro_mfg ."',pro_color='". $pro_color ."',pro_warrenty='". $pro_warrenty ."',pro_soh='". $pro_soh ."',pro_desc='". $pro_desc ."',pro_img1='". $pro_img ."'where pk_pro_id='". $pk_pro_id ."'";
}


?>
