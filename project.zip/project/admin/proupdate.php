<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Blank :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index.html"> <h1>Shoppy</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box-->
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/p1.png" alt=""> </span> 
												<div class="user-name">
													<p>Malorum</p>
													<span>Admin</span>
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
											<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="#"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	
<?php

    
 $conn=new mysqli("localhost","root","","project");

$pro_id=$_GET["id"];
  $sql="select * from product_tbl where pk_pro_id=".$pro_id;
  $result=$conn->query($sql);

$row=$result->fetch_assoc();


$pro_id=$row["pk_pro_id"];
$pro_name=$row["pro_name"];
$pro_price=$row["pro_price"];
$pro_mfg=$row["pro_mfg"];
$pro_color=$row["pro_color"];
$pro_img1=$row["pro_img1"];
$pro_warrenty=$row["pro_warrenty"];
$pro_soh=$row["pro_soh"];
$pro_desc=$row["pro_desc"];
    


?>





<form method="post" class="form-group" action="proupdatecode.php?img=<?php echo $pro_img1?>" enctype="multipart/form-data">
<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">ID</span>
  <input type="text" class="form-control" name="proid" placeholder="Product Id" aria-describedby="sizing-addon2" value=<?php echo $pro_id ?>>
</div>
<br>    

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Name</span>
  <input type="text" class="form-control" name="proname" placeholder="Name" aria-describedby="sizing-addon2" value=<?php echo $pro_name ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Price</span>
  <input type="text" class="form-control" name="proprice" placeholder="Product Price" aria-describedby="sizing-addon2" value=<?php echo $pro_price ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Manufacture</span>
  <input type="text" class="form-control" name="promfg" placeholder="Product Manufacture" aria-describedby="sizing-addon2" value=<?php echo $pro_mfg ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Color</span>
  <input type="text" class="form-control" name="procolor" placeholder="Product ColorName" aria-describedby="sizing-addon2" value=<?php echo $pro_color ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Warrenty</span>
  <input type="text" class="form-control" name="prowarrenty" placeholder="Warrenty" aria-describedby="sizing-addon2" value=<?php echo $pro_warrenty ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">SOH</span>
  <input type="text" class="form-control" name="prosoh" placeholder="Stock on Hand" aria-describedby="sizing-addon2" value=<?php echo $pro_soh ?>>
</div><br>  

<div class="input-group">
  <span class="input-group-addon" id="sizing-addon2">Description</span>
  <input type="text" class="form-control" name="prodesc" placeholder="Description" aria-describedby="sizing-addon2" value=<?php echo $pro_desc ?>>
</div><br>  


<img src="<?php echo $pro_img1?>"><br>  
<input type="file" name="img" >
<input type="submit" name="submit" value="Update">










</form>


    </div>
</div>
<!--inner block end here-->

</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="protable.php"><i class="fa fa-tachometer"></i><span>Product Table</span></a></li>
                <li><a href="cattable.php"><i class="fa fa-th-list"></i><span>Category Table</span></a></li> 
                <li><a href="usertable.php"><i class="fa fa-list-alt"></i><span>User Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Bill Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Cart Table</span></a></li>
		       
		       
		         
		       
		        
		       
		        
		        
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>


                      
						
