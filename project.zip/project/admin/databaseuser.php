<?php
class database{
private static $con=null;
private static function connect(){
    self::$con=mysqli_connect('localhost','root','','project');
    return self::$con;
}

private static function disconnect(){
    mysqli_close(self::$con);
    self::$con=null;
}

public function getUser(){
    $conn=database::connect();
    $sql="select * from user_tbl";
    $res=$conn->query($sql);
    database::disconnect();
    return $res;
}




}
?>