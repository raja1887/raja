<!DOCTYPE HTML>


<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Blank :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index.html"> <h1>Shoppy</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box-->
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
					
							<div class="profile_details">		
								
								<div class="clearfix"> 	<h3><a href="../visitor/products.php">LogOut</a></h3></div>
								

							</div>
											
						</div>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
     <?php
   

   $id=$_GET["id"];
   
   require 'databaseproduct.php';
$obj= new database();
$result=$obj->getProducts($id);

?>

<form action="proupdate.php" method="post">
<div class="container">
<table class="table" align="center">
<thead>
<tr>
<td> <h1>Details</h1>
</thead>
<?php
$row=$result->fetch_assoc();
$id=$row["pk_pro_id"];
echo '<tr>';
echo '<th>Product Pic :';
echo '<td><div class="row">';
  echo'<div class="col-sm-6 col-md-4">';
    echo'<div class="thumbnail">';
      echo'<img src="'.$row["pro_img1"].'" alt="left">';
   

   echo '</div>';
  echo '</div>';
echo '</div>';

echo '<tr>';
echo '<th> Product Name :';
echo '<td> <h2>'.$row["pro_name"].'</h2>';

echo '<tr>';
echo '<th> Price';
echo '<td>'.$row["pro_price"];

echo '<tr>';
echo '<th> Color :';
echo '<td>'.$row["pro_color"];

echo '<tr>';
echo '<th> Warrenty :';
echo '<td>'.$row["pro_warrenty"];


echo '<tr>';
echo '<th> Manufacture :';
echo '<td>'.$row["pro_mfg"];

echo '<tr>';
echo '<th> Stock On Hand :';
echo '<td>'.$row["pro_soh"];

echo '<tr>';
echo '<th> Description :';
echo '<td>'.$row["pro_desc"];


?>
<tr>
<td colspan="2">
<?php 
echo '<a href="proupdate.php?id='. $row["pk_pro_id"] .'" class="btn btn-info"><span class="#">Edit</span></a>'; ?>
     <a href="protable.php" class="btn btn-danger">Back</a>
</table>
</div>
</form>
</div>

<!--inner block end here-->


</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="protable.php"><i class="fa fa-tachometer"></i><span>Product Table</span></a></li>
                <li><a href="cattable.php"><i class="fa fa-th-list"></i><span>Category Table</span></a></li> 
                <li><a href="usertable.php"><i class="fa fa-list-alt"></i><span>User Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Bill Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Cart Table</span></a></li>
		       
		        
		       
		        
		        
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>
