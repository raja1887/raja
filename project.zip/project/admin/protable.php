<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php
session_start();


?>

<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Blank :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="protable.php"> <h1>Shoppy</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
						
								
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">
											<?php
    $conn=new mysqli("localhost","root","","project");
    if($conn->connect_error)
    {
        echo "connection error";
    }
$email=$_SESSION["uname"];
$sql="select * from user_tbl where pk_email_id='".$email."' ";
$result=$conn->query($sql);
$row=$result->fetch_assoc();
$img=$row["profile_pic"];
$name=$row["uname"];
$type=$row["user_type"];

	
												echo '<span class="prfil-img"><img src="'.$img.'" alt="" height="50" width="50"> </span>'; 
												echo '<div class="user-name">';
												echo  '<p>'.$name.'</p>';
												echo  '<span>'.$type.'</span>';
													?>	
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu"> 
											
											<li> <a href="../user/login.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
									</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	
<form action="prodisplay.php" method="post">
<table class="table">
    <thead>
    <th>Product Name
    <th>Price
    <th>Manufacture
    <th>Stock on Hand
    <th>Catagory
    <th>Action
    </thead>
<?php

require 'databaseproduct.php';
$obj= new database();
$result=$obj->getAllProducts();

while($row=$result->fetch_assoc())
{
echo " <tr>";
echo "<td>".$row["pro_name"]."</td>";
echo "<td>".$row["pro_price"]."</td>";
echo "<td>".$row["pro_mfg"]."</td>";
echo "<td>".$row["pro_soh"]."</td>";
echo "<td>".$row["fk_cat_id"]."</td>";
echo '<td><a href="prodelete.php?id='. $row["pk_pro_id"] .'"><span class="glyphicon glyphicon-trash"></span></a></td>';
echo '<td><a href="proupdate.php?id='. $row["pk_pro_id"] .'"><span class="glyphicon glyphicon-edit"></span></a></td>';
echo '<td><a href="proreadmore.php?id='. $row["pk_pro_id"] .'"><span class="#">Read More</span></a></td>';
}



    ?>
</table>
<button><a href="proinsert.php">Insert New Product</a></button>
</form>


    </div>
</div>
<!--inner block end here-->

</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li><a href="protable.php"><i class="fa fa-tachometer"></i><span>Product Table</span></a></li>
                <li><a href="cattable.php"><i class="fa fa-th-list"></i><span>Category Table</span></a></li> 
                <li><a href="usertable.php"><i class="fa fa-list-alt"></i><span>User Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Bill Table</span></a></li>
                <li><a href="#"><i class="fa fa-tachometer"></i><span>Cart Table</span></a></li>
		       
		       
		         
		       
		        
		       
		        
		        
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>


                      
						
