<?php
class database{

private static $con=null;

private static function connect(){

self::$con=mysqli_connect('localhost','root','','project');
return self::$con;

}
private static function disconnect(){

mysqli_close(self::$con);
self::$con=null;

}

public function getAllProducts(){

    $conn=database ::connect();
    $sql="select * from product_tbl";
    $res=$conn->query($sql);
    database ::disconnect();
    return $res;
}

public function deleteProduct($id){

    $conn=database ::connect();
    $sql="select * from product_tbl where pk_pro_id='".$id."'";
    $res=$conn->query($sql);
    $row=$res->fetch_assoc();
    $img=$row["pro_img1"];
        if($img!=null)
        {
        unlink($img);

        $sql="delete from product_tbl where pk_pro_id='".$id."'";
        }
    $res=$conn->query($sql);
    database ::disconnect();
    return $res;
}


public function addProducts($pro_name,$pro_price,$pro_mfg,$pro_color,$pro_warrenty,$pro_soh,$pro_desc,$img,$fk_cat_id)
{
    $conn=database ::connect();
    $sql="insert into product_tbl (pro_name,pro_price,pro_mfg,pro_color,pro_warrenty,pro_soh,pro_desc,pro_img1,fk_cat_id)values('".$pro_name."','".$pro_price."','".$pro_mfg."','".$pro_color."','".$pro_warrenty."','".$pro_soh."','".$pro_desc."','".$img."','".$fk_cat_id."')";
    $res=$conn->query($sql);
    database ::disconnect();
    return $res;
}

public function updateProducts($pro_name,$pro_price,$pro_mfg,$pro_color,$pro_warrenty,$pro_soh,$pro_desc,$pro_img,$pk_pro_id)
{
 $conn=database ::connect();
    $sql="update product_tbl set pro_name='". $pro_name ."',pro_price='". $pro_price ."',pro_mfg='". $pro_mfg ."',pro_color='". $pro_color ."',pro_warrenty='". $pro_warrenty ."',pro_soh='". $pro_soh ."',pro_desc='". $pro_desc ."',pro_img1='". $pro_img ."'where pk_pro_id='". $pk_pro_id ."'";
    $res=$conn->query($sql);
    database ::disconnect();
    return $res;
   
}

public function getProducts($id){
    $conn=database::connect();
    $sql="select p.*,c.* from product_tbl p,cat_tbl c where c.pk_cat_id=p.fk_cat_id and p.pk_pro_id='". $id ."' ";
    $res=$conn->query($sql);
    database::disconnect();
    return $res;
}


}

?>