
 <?php

$cat_id=$_POST["cat_id"];
$cat_name=$_POST["cat_name"];

    require 'databasecat.php';
$obj= new database();
$result=$obj->updateCat($cat_id,$cat_name);

if($result===true){
   header('location:cattable.php');
}
else
{
    echo "not success";
   
}


?>
