<?php
$id=$_GET["id"];
 require 'databaseproduct.php';
   $obj=new database();
   $result=$obj->deleteProduct($id);
 if($result===true)
 {
     header('location:protable.php');
 }
?>