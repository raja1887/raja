<?php




if(isset($_POST["submit"])){

$target_dir="../shared/images/productimg/";
  $img=$target_dir . basename($_FILES["img"]["name"]);
 
 



 

$pro_name=$_POST["proname"];
$pro_price=$_POST["proprice"];
$pro_mfg=$_POST["promfg"];
$pro_color=$_POST["procolor"];
$pro_warrenty=$_POST["prowarrenty"];
$pro_soh=$_POST["prosoh"];
$pro_desc=$_POST["prodesc"];

$fk_cat_id=$_POST["fk_cat_id"];

move_uploaded_file($_FILES["img"]["tmp_name"],$img);

echo $img;

require 'databaseproduct.php';
$obj= new database();
$result=$obj->addProducts($pro_name,$pro_price,$pro_mfg,$pro_color,$pro_warrenty,$pro_soh,$pro_desc,$img,$fk_cat_id);


if($result===true)
{
    echo "successfully";
    header("location:protable.php");
}
else
{
    echo "not success<br>";
    echo "insert into product_tbl (pro_name,pro_price,pro_mfg,pro_color,pro_warrenty,pro_soh,pro_desc,pro_img1,fk_cat_id) values('".$pro_name."','".$pro_price."','".$pro_mfg."','".$pro_color."','".$pro_warrenty."','".$pro_soh."','".$pro_desc."','".$img."','".$fk_cat_id."')";
}
}

?>

